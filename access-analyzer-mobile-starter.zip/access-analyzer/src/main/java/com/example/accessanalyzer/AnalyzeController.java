package com.example.accessanalyzer;

import com.healthmarketscience.jackcess.*;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.*;

@RestController
@RequestMapping("/api")
public class AnalyzeController {
    @PostMapping(value="/analyze", consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String,Object> analyze(@RequestPart("file") MultipartFile upload) throws Exception {
        String name = Optional.ofNullable(upload.getOriginalFilename()).orElse("database.accdb");
        String lower = name.toLowerCase(Locale.ROOT);
        if (!(lower.endsWith(".accdb") || lower.endsWith(".mdb"))) {
            throw new IllegalArgumentException("يرجى اختيار ملف بصيغة ACCDB أو MDB.");
        }
        if (upload.getSize() > 100L * 1024 * 1024) {
            throw new IllegalArgumentException("حجم الملف يتجاوز الحد التجريبي (100 ميغابايت).");
        }

        File temp = File.createTempFile("access-upload-", lower.endsWith(".mdb") ? ".mdb" : ".accdb");
        try {
            upload.transferTo(temp);
            List<Map<String,Object>> tables = new ArrayList<>();
            try (Database db = DatabaseBuilder.open(temp)) {
                for (Table table : db) {
                    Map<String,Object> t = new LinkedHashMap<>();
                    t.put("name", table.getName());
                    List<Map<String,Object>> columns = new ArrayList<>();
                    for (Column c : table.getColumns()) {
                        Map<String,Object> col = new LinkedHashMap<>();
                        col.put("name", c.getName());
                        col.put("type", c.getType().name());
                        col.put("length", c.getLength());
                        col.put("required", c.isRequired());
                        columns.add(col);
                    }
                    t.put("columns", columns);
                    tables.add(t);
                }
            }
            Map<String,Object> result = new LinkedHashMap<>();
            result.put("fileName", name);
            result.put("tableCount", tables.size());
            result.put("tables", tables);
            result.put("notice", "تم استخراج أسماء الجداول والحقول فقط. لم يتم تعديل الملف.");
            return result;
        } finally {
            if (temp.exists()) temp.delete();
        }
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(org.springframework.http.HttpStatus.BAD_REQUEST)
    public Map<String,String> handle(Exception e) {
        return Map.of("error", Optional.ofNullable(e.getMessage()).orElse("تعذر تحليل الملف."));
    }
}
